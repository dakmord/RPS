#ifndef __TM4C1294NCPDT__
 #define __TM4C1294NCPDT__
#endif

#include "gpioEnergia.h"

void energiaWrite(unsigned char pin, unsigned char val)
{
#ifndef MATLAB_MEX_FILE

    pinMode(pin, OUTPUT);
	digitalWrite(pin, val);
#endif
}

unsigned char energiaRead(unsigned char pin)
{
#ifndef MATLAB_MEX_FILE
    pinMode(pin, INPUT_PULLUP); 
	return digitalRead(pin);
#endif
	
}