energiaWrite = legacy_code('initialize');
energiaWrite.SFunctionName = 'sfunc_energiaRead';
energiaWrite.HeaderFiles = {'gpioEnergia.h'};
energiaWrite.SourceFiles = {'gpioEnergia.c'};
%energiaWrite.OutputFcnSpec = 'energiaWrite(uint8 u1, uint8 u2)';
energiaWrite.OutputFcnSpec = 'uint8 y1 = energiaRead(uint8 u1)';
energiaWrite.SampleTime = 'parameterized';

legacy_code('sfcn_cmex_generate', energiaWrite);
legacy_code('compile', energiaWrite);
legacy_code('slblock_generate', energiaWrite);
legacy_code('sfcn_tlc_generate', energiaWrite);

