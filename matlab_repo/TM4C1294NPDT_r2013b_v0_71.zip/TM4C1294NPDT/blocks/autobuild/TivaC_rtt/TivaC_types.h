/* 
 * File: TivaC_types.h
 *  
 * Code generated for Simulink model 'TivaC'.
 * 
 * Model version                  : 1.49
 * Simulink Coder version         : 8.5 (R2013b) 08-Aug-2013
 * TLC version                    : 8.5 (Aug  6 2013)
 * C/C++ source code generated on : Tue Apr 07 14:53:05 2015
 * 
 * Target selection: realtime.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */



  #ifndef RTW_HEADER_TivaC_types_h_
  #define RTW_HEADER_TivaC_types_h_

#include "rtwtypes.h"









      
            /* Parameters (auto storage) */
       typedef struct P_TivaC_T_ P_TivaC_T;
          /* Forward declaration for rtModel */
      typedef struct tag_RTM_TivaC_T RT_MODEL_TivaC_T;













  #endif /* RTW_HEADER_TivaC_types_h_ */

/* 
 * File trailer for generated code.
 * 
 * [EOF]
 */

