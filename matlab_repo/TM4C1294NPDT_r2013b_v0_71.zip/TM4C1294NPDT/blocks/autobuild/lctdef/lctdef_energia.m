function def = lctdef_energia()
%% energiaWrite TEST
energiaWrite = legacy_code('initialize');
energiaWrite.SFunctionName = 'stellaris_lp_sfunc_energiaWrite';
energiaWrite.HeaderFiles = {'gpioEnergia.h'};
energiaWrite.SourceFiles = {'gpioEnergia.c'};
energiaWrite.OutputFcnSpec = 'energiaWrite(uint8 u1)';
energiaWrite.SampleTime = 'parameterized';


def = energiaWrite(:);
end