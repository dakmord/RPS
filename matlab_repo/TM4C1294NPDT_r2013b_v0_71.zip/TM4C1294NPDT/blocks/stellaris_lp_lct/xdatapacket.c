#ifdef MATLAB_MEX_FILE
// build mex file
    #include "xdatapacket.h"
    // no code in this one.
#else

#include "stellaris_runtime.h"
#include "uartx_driver.h"
#include "xdatapacket.h"

int init_xdatapacket(int baud)
{
    // uart 1
    uartx_init((unsigned long)baud);
    // skip packet size check for now.
    return 1;
}

int xdatapacket_get(int pkt_size, unsigned char *data)
{
    int n;
    
    if (uartx_read_pending()>=pkt_size)
    {
        n= pkt_size;    
        while(n--)
        {
            uartx_read_one(data++); // data copy
        }
        return 1; //signal new data arrival
    }
    else
    {
        return 0;
    }
}

int xdatapacket_put(int pkt_size, unsigned char *data)
{
    int n;
    
    if (uartx_write_pending()+pkt_size <= UARTX_TX_BUF_SIZE)
    {
        n= pkt_size;    
        while(n--)
        {
            uartx_write_one(data++); // data copy
        }
        return 1; //send complete
    }else
    {
        return 0;
    }
}

#endif
