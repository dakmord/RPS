#ifndef DATAPACKET_H_
#define DATAPACKET_H_

#define init_xdatapacket_void()             (0)

#ifdef MATLAB_MEX_FILE

    #define init_xdatapacket(a)             (0)
    #define xdatapacket_get(a,b,c)          (0)
    #define xdatapacket_put(a,b,c)          (0)
#else

int init_xdatapacket(int baud);
int xdatapacket_get(int pkt_size, unsigned char *data);
int xdatapacket_put(int pkt_size, unsigned char *data);

#endif //MATLAB_MEX_FILE

#endif /* DATAPACKET_H_ */
