#ifndef __ENERGIA_RUNTIME_H__
#define __ENERGIA_RUNTIME_H__

extern void _init(void);


#endif // __STELLARIS_RUNTIME_H__
