#ifndef __GPIOENERGIA_H
 #define __GPIOENERGIA_H

#ifndef MATLAB_MEX_FILE
 #include <stdint.h>
 #include <stdbool.h>
 #include "Energia.h"
#endif

void energiaWrite(unsigned char pin, unsigned char val);
unsigned char energiaRead(unsigned char pin);
#endif
