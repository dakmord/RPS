/* 
 * File: TivaC.h
 *  
 * Code generated for Simulink model 'TivaC'.
 * 
 * Model version                  : 1.49
 * Simulink Coder version         : 8.5 (R2013b) 08-Aug-2013
 * TLC version                    : 8.5 (Aug  6 2013)
 * C/C++ source code generated on : Tue Apr 07 14:53:05 2015
 * 
 * Target selection: realtime.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */



  #ifndef RTW_HEADER_TivaC_h_
  #define RTW_HEADER_TivaC_h_
    #ifndef TivaC_COMMON_INCLUDES_
  # define TivaC_COMMON_INCLUDES_
    #include <string.h>
    #include "rtwtypes.h"
    #include "rtw_continuous.h"
    #include "rtw_solver.h"
    #include "gpioEnergia.h"
  #endif /* TivaC_COMMON_INCLUDES_ */
  

    #include "TivaC_types.h"    





    /* Macros for accessing real-time model data structure */
    

    #ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm) ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val) ((rtm)->errorStatus = (val))
#endif


  
   
    
      






    
          /* Block states (auto storage) for system '<Root>' */
              
        
  
     typedef struct  {
  
            
                    
          
                int32_T clockTickCounter; /* '<Root>/Pulse Generator1' */
                          
        

          
          
                    
          
                int32_T clockTickCounter_b; /* '<Root>/Pulse Generator2' */
                          
        

          

  
    } DW_TivaC_T;
  

      
              
            /* Parameters (auto storage) */
      
        struct P_TivaC_T_ {
                      
             real_T Constant_Value; /* Expression: pin
    * Referenced by: '<S1>/Constant'
   */
            
             real_T PulseGenerator1_Amp; /* Expression: 1
    * Referenced by: '<Root>/Pulse Generator1'
   */
            
             real_T PulseGenerator1_Period; /* Expression: 6
    * Referenced by: '<Root>/Pulse Generator1'
   */
            
             real_T PulseGenerator1_Duty; /* Expression: 3
    * Referenced by: '<Root>/Pulse Generator1'
   */
            
             real_T PulseGenerator1_PhaseDelay; /* Expression: 0
    * Referenced by: '<Root>/Pulse Generator1'
   */
            
             real_T Constant_Value_c; /* Expression: pin
    * Referenced by: '<S2>/Constant'
   */
            
             real_T PulseGenerator2_Amp; /* Expression: 1
    * Referenced by: '<Root>/Pulse Generator2'
   */
            
             real_T PulseGenerator2_Period; /* Expression: 12
    * Referenced by: '<Root>/Pulse Generator2'
   */
            
             real_T PulseGenerator2_Duty; /* Expression: 6
    * Referenced by: '<Root>/Pulse Generator2'
   */
            
             real_T PulseGenerator2_PhaseDelay; /* Expression: 0
    * Referenced by: '<Root>/Pulse Generator2'
   */
  

        };
      
      

        /* Real-time Model Data Structure */
      struct tag_RTM_TivaC_T {
        const char_T * volatile errorStatus;

              /*
     * Timing:
           * The following substructure contains information regarding
      * the timing information for the model.
      */
   struct  {
          struct {
    uint8_T TID[2];
  }  TaskCounters;

    } Timing;

    };

      
        
          




    
      /* Block parameters (auto storage) */
                extern P_TivaC_T TivaC_P;



      
        /* Block states (auto storage) */
                extern DW_TivaC_T TivaC_DW;



    


      /* Model entry point functions */
            extern void TivaC_initialize(void);
                      extern void TivaC_output(void);
                          extern void TivaC_update(void);
                    extern void TivaC_terminate(void);
          



          
          /* Real-time Model object */
          
                            extern RT_MODEL_TivaC_T *const TivaC_M;



          





      
  /*-
   * The generated code includes comments that allow you to trace directly 
   * back to the appropriate location in the model.  The basic format
   * is <system>/block_name, where system is the system number (uniquely
   * assigned by Simulink) and block_name is the name of the block.
   *
   * Use the MATLAB hilite_system command to trace the generated code back
   * to the model.  For example,
   *
   * hilite_system('<S3>')    - opens system 3
   * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
   *
   * Here is the system hierarchy for this model
   *
    * '<Root>' : 'TivaC'
      * '<S1>'   : 'TivaC/TM4C1294_Digital_Write'
      * '<S2>'   : 'TivaC/TM4C1294_Digital_Write1'
   */



  #endif /* RTW_HEADER_TivaC_h_ */

/* 
 * File trailer for generated code.
 * 
 * [EOF]
 */

