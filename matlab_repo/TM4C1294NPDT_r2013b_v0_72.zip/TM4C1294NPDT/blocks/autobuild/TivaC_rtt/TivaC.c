/* 
 * File: TivaC.c
 *  
 * Code generated for Simulink model 'TivaC'.
 * 
 * Model version                  : 1.49
 * Simulink Coder version         : 8.5 (R2013b) 08-Aug-2013
 * TLC version                    : 8.5 (Aug  6 2013)
 * C/C++ source code generated on : Tue Apr 07 14:53:05 2015
 * 
 * Target selection: realtime.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */


      #include "TivaC.h"

        #include "TivaC_private.h"












  
    
  

  
      
    
    
    
    
    
    
    
      /* Block states (auto storage) */
                  DW_TivaC_T TivaC_DW;

        
	/* Real-time model */
          RT_MODEL_TivaC_T TivaC_M_;

          RT_MODEL_TivaC_T *const TivaC_M = &TivaC_M_;





static void rate_scheduler(void);


    
       
    
    
   
        /* 
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */

                static void rate_scheduler(void)
        {
            
  /* Compute which subrates run during the next base time step.  Subrates
  * are an integer multiple of the base rate counter.  Therefore, the subtask
  * counter is reset when it reaches its limit (zero means run).
  */
        (TivaC_M->Timing.TaskCounters.TID[1])++;
      if ((TivaC_M->Timing.TaskCounters.TID[1]) > 9) { /* Sample time: [0.1s, 0.0s] */
         TivaC_M->Timing.TaskCounters.TID[1] = 0;
      } 


        }
            

  
  
  
    
  

  
  
    
          
          
    /* Model output function */
            void TivaC_output(void) 
    {
      
    
    
          
                  /* local block i/o variables */
        	
	
              uint8_T rtb_DataTypeConversion;


              uint8_T rtb_DataTypeConversion1;




      real_T rtb_PulseGenerator2;



      

        
  



         
        
  



                                  


if (TivaC_M->Timing.TaskCounters.TID[1] == 0) {
    /* DataTypeConversion: '<S1>/Data Type Conversion1' incorporates:
 *  Constant: '<S1>/Constant'
 */
    if (TivaC_P.Constant_Value < 256.0) {
        if (TivaC_P.Constant_Value >= 0.0) {
            rtb_DataTypeConversion = (uint8_T)TivaC_P.Constant_Value;
        } else {
            rtb_DataTypeConversion = 0U;
        }
    } else {
        rtb_DataTypeConversion = MAX_uint8_T;
    }
    /* End of DataTypeConversion: '<S1>/Data Type Conversion1' */

    /* DiscretePulseGenerator: '<Root>/Pulse Generator1' */
    rtb_PulseGenerator2 = (TivaC_DW.clockTickCounter < TivaC_P.PulseGenerator1_Duty) && (TivaC_DW.clockTickCounter >= 0) ? TivaC_P.PulseGenerator1_Amp : 0.0;
    if (TivaC_DW.clockTickCounter >= TivaC_P.PulseGenerator1_Period - 1.0) {
        TivaC_DW.clockTickCounter = 0;
    } else {
        TivaC_DW.clockTickCounter++;
    }
    /* End of DiscretePulseGenerator: '<Root>/Pulse Generator1' */

    /* DataTypeConversion: '<S1>/Data Type Conversion' */
    if (rtb_PulseGenerator2 < 256.0) {
        if (rtb_PulseGenerator2 >= 0.0) {
            rtb_DataTypeConversion1 = (uint8_T)rtb_PulseGenerator2;
        } else {
            rtb_DataTypeConversion1 = 0U;
        }
    } else {
        rtb_DataTypeConversion1 = MAX_uint8_T;
    }
    /* End of DataTypeConversion: '<S1>/Data Type Conversion' */
      
/* S-Function (sfunc_energiaWrite): '<S1>/sfunc_energiaWrite' */                  energiaWrite( (uint8_T)rtb_DataTypeConversion, (uint8_T)rtb_DataTypeConversion1);
 
   
        
    /* DataTypeConversion: '<S2>/Data Type Conversion1' incorporates:
 *  Constant: '<S2>/Constant'
 */
    if (TivaC_P.Constant_Value_c < 256.0) {
        if (TivaC_P.Constant_Value_c >= 0.0) {
            rtb_DataTypeConversion1 = (uint8_T)TivaC_P.Constant_Value_c;
        } else {
            rtb_DataTypeConversion1 = 0U;
        }
    } else {
        rtb_DataTypeConversion1 = MAX_uint8_T;
    }
    /* End of DataTypeConversion: '<S2>/Data Type Conversion1' */

    /* DiscretePulseGenerator: '<Root>/Pulse Generator2' */
    rtb_PulseGenerator2 = (TivaC_DW.clockTickCounter_b < TivaC_P.PulseGenerator2_Duty) && (TivaC_DW.clockTickCounter_b >= 0) ? TivaC_P.PulseGenerator2_Amp : 0.0;
    if (TivaC_DW.clockTickCounter_b >= TivaC_P.PulseGenerator2_Period - 1.0) {
        TivaC_DW.clockTickCounter_b = 0;
    } else {
        TivaC_DW.clockTickCounter_b++;
    }
    /* End of DiscretePulseGenerator: '<Root>/Pulse Generator2' */

    /* DataTypeConversion: '<S2>/Data Type Conversion' */
    if (rtb_PulseGenerator2 < 256.0) {
        if (rtb_PulseGenerator2 >= 0.0) {
            rtb_DataTypeConversion = (uint8_T)rtb_PulseGenerator2;
        } else {
            rtb_DataTypeConversion = 0U;
        }
    } else {
        rtb_DataTypeConversion = MAX_uint8_T;
    }
    /* End of DataTypeConversion: '<S2>/Data Type Conversion' */
      
/* S-Function (sfunc_energiaWrite): '<S2>/sfunc_energiaWrite' */                  energiaWrite( (uint8_T)rtb_DataTypeConversion1, (uint8_T)rtb_DataTypeConversion);
 
   
        
}






        
  


        

    
    


      
        
  

    }
    

          
    
    /* Model update function */
            void TivaC_update(void) 
    {
      
    
    
    
    
        
    
    
      
  



          
  



                          
  



        
  
  
    
    

      
        

    


    
          rate_scheduler();

  
  

    

    
    
    

      
      
    }
    



  







  /* Model initialize function */
      void TivaC_initialize(void)
  {
            
      
      
        
    
    
    
        
    
    
        /* Registration code */
        
  
  



      
          /* initialize real-time model */
          (void) memset((void *)TivaC_M, 0,
sizeof(RT_MODEL_TivaC_T));
          
  
  

  

  





      

    

        
  
  

  
  
     
  

  


    /* states (dwork) */
    
        

    
        
                    
        (void) memset((void *)&TivaC_DW,  0,
 sizeof(DW_TivaC_T));

    
        
  
    

    


  

    
      
        

  

  
      
          
    
    

    

    
      
        
  



      
  



                              /* Start for DiscretePulseGenerator: '<Root>/Pulse Generator1' */
TivaC_DW.clockTickCounter = 0;
/* Start for DiscretePulseGenerator: '<Root>/Pulse Generator2' */
TivaC_DW.clockTickCounter_b = 0;



  
  



    
      
    
    
        

  

      
        
  

  }








  
    
    /* Model terminate function */
        void TivaC_terminate(void)

    {
      
      /* (no terminate code required) */



          
  

    }
    



  
  
   







/* 
 * File trailer for generated code.
 * 
 * [EOF]
 */

