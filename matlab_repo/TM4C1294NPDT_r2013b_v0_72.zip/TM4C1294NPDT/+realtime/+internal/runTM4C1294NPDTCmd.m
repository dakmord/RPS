function ret = runTM4C1294NPDTCmd (cmd, varargin )
switch (cmd)
    case 'download'
        narginchk(3, 3);
        ret = i_TM4C1294NPDT_download(varargin{1}, varargin{2});
    case 'setup_com'
        narginchk(1, 1);
        ret = i_TM4C1294NPDT_setup;
    case 'opendemo'
        narginchk(2, 2);
        open_system(['stellaris_lp_' varargin{1} ]);
        ret =[]; 
    case 'compilecomm'
        i_TM4C1294NPDT_compilecomm
    case 'buildblock'
        if nargin == 2
            i_TM4C1294NPDT_buildblock(varargin{1})
        end
    case 'blockdecltmpl'
        
        if exist(fullfile('.','rtwmakecfgTM4C1294NPDT_user.m'),'file')
            reply = input('File exist in current directory. Do you want overwrite? Y/N [N]:','s');
            if isempty(reply)
              reply = 'N';
            end
            if reply == 'N'
                return
            end
        end
        copyfile(fullfile(realtime.internal.getTM4C1294NPDTInfo('PackageDir'),...
                          'registry','rtwmakecfgTM4C1294NPDT_user.m.tmpl'), ...
                 'rtwmakecfgTM4C1294NPDT_user.m');
    case 'runcommsvr'
        d = pwd();
        cd(fullfile(realtime.internal.getTM4C1294NPDTInfo('PackageDir'), ...
             'utils'));
        system('MPCOM.exe  &');
        cd(d);
    case 'editcommsvrcfg'
        edit(fullfile(realtime.internal.getTM4C1294NPDTInfo('PackageDir'), ...
             'utils','setting.ini'));
    case 'generateCoreLibrary'
        generateCoreLibrary;
    case 'getEthernetParameter'
        ret = getEthernetParameter;
    otherwise
        error('Invalid TM4C1294NPDT command!');
end
end

function i_TM4C1294NPDT_buildblock(def)
%def = lctdef_LS7366();
legacy_code('SFCN_CMEX_GENERATE', def);
legacy_code('COMPILE', def);
delete([def.SFunctionName '.cpp']);

%legacy_code('SLBLOCK_GENERATE', def, ['block_' def.SFunctionName]);

legacy_code('rtwmakecfg_generate', def);
C = textread('rtwmakecfg.m', '%s','delimiter', '\n'); %#ok<REMFF1>
l= strmatch('% Dependency info for S-function ', C); %#ok<MATCH2>
delete('rtwmakecfg.m');


disp(['Clip the following between double lines and paste into ' , ...
      'rtwmakecfgTM4C1294NPDT_user in your path']);
disp('==================================================================');
fprintf(['%%%% ' def.SFunctionName '\ninfo = info_tmpl;' '%s' '\narray = [array info];\n'],strjoin(unique(C(l+1:end)'),'\n'));
disp('==================================================================');
end

function i_TM4C1294NPDT_compilecomm()
d = pwd();
try
cd(matlabroot())

% serial protocol on a tcp transport
mex rtw\ext_mode\common\ext_comm.c ...
    rtw\ext_mode\common\ext_convert.c ...
    rtw\ext_mode\serial\ext_serial_transport.c ...
    rtw\ext_mode\serial\ext_serial_pkt.c ...
    rtw\ext_mode\serial\rtiostream_serial_interface.c ...
    rtw\ext_mode\common\ext_util.c ...
    -Irtw\c\src -Irtw\c\src\rtiostream\utils ...
    -Irtw\c\src\ext_mode\common ...
    -Irtw\c\src\ext_mode\serial -Irtw\ext_mode\common ...
    -Irtw\ext_mode\common\include ...
    -lmwrtiostreamutils ...
    -DEXTMODE_TCPIP_TRANSPORT -DSL_EXT_DLL ...
    -output toolbox\rtw\rtw\ext_serial_win32_mp_comm
catch err
    cd(d);
    rethrow(err);
end
cd(d)

end

% This function is modified from Mikhail's TM4C1294NPDT package
function ret = i_TM4C1294NPDT_download(modelName, output_path)

disp(['### Downloading ', modelName, ' to TM4C1294NPDT LaunchPad [' getpref('TM4C1294NPDT','COMPort') ']...']);

TargetRoot = realtime.internal.getTM4C1294NPDTInfo('PackageDir');
CCSRoot = ''; % obsolete: realtime.internal.getTM4C1294NPDTInfo('CCSDir');
%ArmCC = realtime.internal.getTM4C1294NPDTInfo('ArmCCDir');
%{
if (ischar(makertwObj)) %String 'PIL'
    outfile = modelName;
else
    outfile = fullfile(makertwObj.BuildDirectory, [modelName, '.out']);
    %outfilebin = fullfile(makertwObj.BuildDirectory, [modelName, '.bin']);
end
%}

% % obj2bin tools 
% ofd = fullfile(ArmCC,'bin','armofd');
% hex = fullfile(ArmCC,'bin','armhex');
% mkhex = fullfile(TargetRoot,'utils','tiobj2bin','mkhex4bin');
% tiobj2bin = fullfile(TargetRoot,'utils','tiobj2bin','tiobj2bin');
% flash util
lm4flash =  fullfile(TargetRoot,'utils','lm4flash','lmflash');

outfile = fullfile(output_path, [modelName, '.out']);
binfile = fullfile(output_path, [modelName, '.bin']);

if isunix
    % Convert out to bin for lm4flash
    %system([CCSRoot,'/utils/tiobj2bin/tiobj2bin ',outfile,' ',outfilebin,' ',...
    %    CompilerRoot,'/bin/armofd ',CompilerRoot, '/bin/armhex ',CCSRoot,'/utils/tiobj2bin/mkhex4bin']);
    %TODO fail gracefully here.
    
    % TODO : have not tested this.
    ret = system(['"' lm4flash '" -q ek-tm4c1294xl -r "' binfile '" >/dev/null']);
        
    %ret = system(['LD_PRELOAD="',CCSRoot,'/ccs_base/DebugServer/bin/libti_xpcom.so" "',`,'/ccs_base/scripting/examples/loadti/loadti.sh" -a -r ',...
    %    '-c "',TargetRoot,'/registry/TM4C1294NPDT_LaunchPad.ccxml" ',...
    %    '"',outfile,'" 2> /dev/null']);
else
    %construct hex file taken care of in TM4C1294NPDT.m in registry
    %ret = system(['"' tiobj2bin '" "' outfile '" "' binfile  '" "' ofd '" "' hex '" "' mkhex '"']);
    ret = system(['"' lm4flash '" -q ek-tm4c1294xl -r "' binfile '" >NUL']);
    
    % old loadti.bat loading mechanism
    %ret = system(['"',CCSRoot,'/ccs_base/scripting/examples/loadti/loadti.bat" -a -r ',...
    %    '-c "',TargetRoot,'/registry/Stellaris_LaunchPad.ccxml" ',...
    %    '"',outfile,'" 2 > NUL']);
end

if ret == 0
    disp(['### Successfully downloaded ', modelName, ' to TM4C1294NPDT LaunchPad.']);
    ret =1;
else
    disp(['### Failed to download ', modelName, ' to TM4C1294NPDT LaunchPad.']);
    ret =0;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret = i_TM4C1294NPDT_setup
    pref_group = 'TM4C1294NPDT';
    [COMPort, flag] = setup_com_port;
    ret = flag;
    setpref(pref_group,'COMPort',COMPort);
    %[~, ArmCCDir, StellarisWareDir] = ccs_setup_paths;
    %setpref(pref_group,'CCSDir','');
    %setpref(pref_group,'ArmCCDir',ArmCCDir);
    %setpref(pref_group,'StellarisWareDir',StellarisWareDir);
end

%
% code below is from Mikhail's Stellaris package.
% 
%

function [CCSRoot, CompilerRoot, StellarisWareRoot] = ccs_setup_paths()
	% TODO: make it foolproof
    % CCSRoot = fix_slash(uigetdir(matlabroot,'CCS root directory: (the one with ccs_base, tools ...)'));
    homeDir = getParentDir(2, '\');
    CompilerRoot = [homeDir 'toolchains\thirdpartytools\ti-cgt-arm_5.2.2\'];
    %StellarisWareRoot = [homeDir 'toolchains\thirdpartytools\TivaWare_C_Series-2.1.0.12573\'];
    StellarisWareRoot = [homeDir 'toolchains\thirdpartytools\energia-0101E0014\hardware\lm4f\cores\lm4f\'];
    CCSRoot = '';
end

function [COMPort, flag] = setup_com_port()
COMPort = '';
[ports, names] = find_com_ports;
assignin('base', 'ports', ports);
assignin('base', 'names', names);

[x,y] = size(names);
for i=1:y
   startIndex = regexp(names(1,i),'Stellaris Virtual Serial Port');
   if cell2mat(startIndex) ~= 0
      COMPort = char(ports{i});
      flag = 1;
   end
end
if isempty(COMPort)
   disp('empty'); 
   disp(' ### Error: Could not resolve correct COMPort for "Stellaris Virtual Serial Port"');
   disp(' ### Using standard COMPort: "COM10"');
   disp(' ### -> Maybe COM-Driver is not installed. This can lead to flashing problems!')
   COMPort = 'COM10';
   flag = 0;
end

% Choose COM port
%[selection,ok] = listdlg('PromptString','Choose TI Stellaris LaunchPad COM port:',...
%    'SelectionMode','single',...
%    'ListSize',[260 160],...
%    'ListString',names);
% if (ok == 1 && selection > 2) %have actually chosen COM port
%     COMPort = char(ports{selection-2}); % -2 for padding with names array
% elseif (ok == 1 && selection > 1) %chosen to refresh COM Ports
%     COMPort = setup_com_port();
% else %chosen to enter manually or canceled
%     COMPort = cell2mat(inputdlg('Enter COM port manually: (ex. COM3 or ttyACM0)','COM port',1));
% end
end

function [ports, names] = find_com_ports()
%Find COM ports
%names_string = {'Enter COM port manually...','Refresh COM ports list...'};
if isunix
    %TODO
	%check /dev/serial
	unixCmd = 'ls -l /dev/serial/by-id/*';
	[unixCmdStatus,unixCmdOutput]=system(unixCmd);
	if (unixCmdStatus > 0)
		ports = {};
		names = {};
	else
		%names = regexp(unixCmdOutput,'(?<=/dev/serial/by-id/)\S+','match');
		%ports = regexp(unixCmdOutput,'(?<=->.*/)tty\w+','match');
		[names, ports] = regexp(unixCmdOutput,'(?<=/dev/serial/by-id/)\S.*?((?<=->.*/)tty\w+)','match','tokens');
	end
else
    wmiCmd = ['wmic /namespace:\\root\cimv2 '...
              'path Win32_SerialPort get DeviceID,Name'];
    %TODO catch error (wmic is not on WinXP Home for instance).
    [~,wmiCmdOutput]=system(wmiCmd);
    % in a single regexp call with tokens
    [names, ports] = regexp(wmiCmdOutput,'(?<=COM\d+\s*)\S.*?\((COM\d+)\)','match','tokens');
    % same in two regexp calls..
    %ports = regexp(wmiCmdOutput,'COM\d+(?!\))','match');
    %names = regexp(wmiCmdOutput,'(?<=COM\d+\s*)\S.*?\(COM\d+\)','match');
    %regCmd=['reg query '...
    %        'HKEY_LOCAL_MACHINE\HARDWARE\DEVICEMAP\SERIALCOMM'];
    %[~,regCmdOutput]=system(regCmd);
    %ports = regexp(regCmdOutput,'COM\d+','match');
end
names = [names];
end

function path = fix_slash(path0)
path = path0;
if ispc
    path(path=='\')='/';
end
end

function generateCoreLibrary
    ArmCC = realtime.internal.getTM4C1294NPDTInfo('ArmCCDir');
    StellarisDir = realtime.internal.getTM4C1294NPDTInfo('StellarisWareDir');
    libFile = fullfile(StellarisDir, 'driverlib', 'core.a');
    
    % Check if core.a is already existing and skip CoreLib generation...
    if ~isequal(exist(libFile, 'file'),2) % 7 = directory.
        % Compile *.c/*.cpp files and generate *.o files...
        generateBasicLibObjectFiles;
        generateCustomLibObjectFiles;

        % Delete old core.a file...
        if isequal(exist(libFile, 'file'),2) % 7 = directory.
            delete(libFile);
        end

        % Define Strings for CMD
        arPath = fullfile(ArmCC, 'bin', 'arm-none-eabi-ar.exe');

        % Add all *.o files to core.a using archiever...
        fPath = fullfile(StellarisDir);
        fNames = dir( fullfile(fPath,'*.o') );
        fNames = strcat({fNames.name});
        %# process each *.o file
        for i=1:length(fNames)
            tmpFile = fullfile(StellarisDir, fNames{i});
            cmd=sprintf('%s -rcs %s %s', arPath, libFile, tmpFile);
            [status, cmdout] = dos(cmd); 
        end

        % Delete all object files...
        fPath = fullfile(StellarisDir);
        fNames = dir( fullfile(fPath,'*.o') );
        fNames = strcat({fNames.name});
        for i=1:length(fNames)
            delete(fullfile(StellarisDir, fNames{i}));
        end
        fPath = fullfile(StellarisDir);
        fNames = dir( fullfile(fPath,'*.d') );
        fNames = strcat({fNames.name});
        for i=1:length(fNames)
            delete(fullfile(StellarisDir, fNames{i}));
        end
        % DONE Deleting...
    end
end

function generateBasicLibObjectFiles
    ArmCC = realtime.internal.getTM4C1294NPDTInfo('ArmCCDir');
    StellarisDir = realtime.internal.getTM4C1294NPDTInfo('StellarisWareDir');
    
    % gcc and g++ compilers
    gccPath = fullfile(ArmCC, 'bin', 'arm-none-eabi-gcc.exe');
    gppPath = fullfile(ArmCC, 'bin', 'arm-none-eabi-g++.exe');
    % build a list of *.c files 
    fPath = fullfile(StellarisDir);
    fNames = dir( fullfile(fPath,'*.c') );
    fNames = strcat({fNames.name});
    % compile each file
    flags = '-c -Os -w -ffunction-sections -fdata-sections -mthumb -mcpu=cortex-m4 -mfloat-abi=hard -mfpu=fpv4-sp-d16 -fsingle-precision-constant -DF_CPU=120000000L -MMD -DARDUINO=101 -DENERGIA=14';
    includes =['-I' StellarisDir ' -I' fullfile(StellarisDir, 'driverlib')];
    for i=1:length(fNames)
        tmpFile = fullfile(StellarisDir, fNames{i});
        if ~isequal(fNames{i}, 'startup_gcc.c') % excluding startup_gcc.c because already in src dir
        [cmd]=sprintf('%s %s %s %s -o %s', gccPath,flags, includes, tmpFile, [tmpFile '.o']);
        [status, cmdout] = dos(cmd);
        end
    end
    
    % build a list of *.cpp files
    fPath = fullfile(StellarisDir);
    fNames = dir( fullfile(fPath,'*.cpp') );
    fNames = strcat({fNames.name});
    %# compile each file
    flags = '-c -Os -w -ffunction-sections -fdata-sections -mthumb -mcpu=cortex-m4 -mfloat-abi=hard -mfpu=fpv4-sp-d16 -fsingle-precision-constant -DF_CPU=120000000L -MMD -DARDUINO=101 -DENERGIA=14';
    includes =['-I' StellarisDir ' -I' fullfile(StellarisDir, 'driverlib')];
    for i=1:length(fNames)
        tmpFile = fullfile(StellarisDir, fNames{i});
        if ~isequal(fNames{i}, 'main.cpp') % excluding main.cpp because simulink is generating a main
        [cmd]=sprintf('%s %s %s %s -o %s', gppPath,flags, includes, tmpFile, [tmpFile '.o']);
        [status, cmdout] = dos(cmd);
        end
    end
end

function generateCustomLibObjectFiles
% get all needed paths/dirs
    ArmCC = realtime.internal.getTM4C1294NPDTInfo('ArmCCDir');
    energiaHomeDir = realtime.internal.getTM4C1294NPDTInfo('EnergiaHome');
    StellarisDir = realtime.internal.getTM4C1294NPDTInfo('StellarisWareDir');
    % custom lib dirs
    energiaVariantsDir = fullfile(energiaHomeDir,'hardware', 'lm4f', 'variants');
    energiaLibrariesDir = fullfile(energiaHomeDir,'hardware', 'lm4f', 'libraries');
    ethernetDir = fullfile(energiaLibrariesDir, 'Ethernet');
    ethernetUtilityDir = fullfile(energiaLibrariesDir, 'Ethernet', 'utility');
    spiDir = fullfile(energiaLibrariesDir, 'SPI');
    servoDir = fullfile(energiaLibrariesDir, 'Servo');
    stepperDir = fullfile(energiaLibrariesDir, 'Stepper');
    
    % add paths to cell
    pathCell = {};
    pathCell{end+1} = StellarisDir;
    pathCell{end+1} = ethernetDir;
    pathCell{end+1} = ethernetUtilityDir;
    pathCell{end+1} = spiDir;
    pathCell{end+1} = servoDir;
    pathCell{end+1} = stepperDir;
    
    %compilers
    gccPath = fullfile(ArmCC, 'bin', 'arm-none-eabi-gcc.exe');
    gppPath = fullfile(ArmCC, 'bin', 'arm-none-eabi-g++.exe');
    flags = '-c -Os -w -fno-rtti -fno-exceptions -ffunction-sections -fdata-sections -mthumb -mcpu=cortex-m4 -mfloat-abi=hard -mfpu=fpv4-sp-d16 -fsingle-precision-constant -DF_CPU=120000000L -MMD -DARDUINO=101 -DENERGIA=14';
    % generate object files for *.c and *.cpp files contained in the dirs
    for p = 1:length(pathCell)
        fPath = fullfile(pathCell{p});
        fNames = dir( fullfile(fPath,'*.c') );
        fNames = strcat({fNames.name});
        % compile each *.c file
        includes =['-I' StellarisDir ' -I' pathCell{p} ' -I' ethernetDir ' -I' fullfile(energiaVariantsDir, 'launchpad_129')];
        for i=1:length(fNames)
            tmpFile = fullfile(pathCell{p}, fNames{i});
            [cmd]=sprintf('%s %s %s %s -o %s', gccPath,flags, includes, tmpFile, [fullfile(StellarisDir, fNames{i}) '.o']);
            [status, cmdout] = dos(cmd);
            % Check for Errors during compilation
            if status==1
                disp(cmdout);
            end
        end
        % compile each *.cpp file
        fNames = dir( fullfile(fPath,'*.cpp') );
        fNames = strcat({fNames.name});
        % compile each *.c file
        for i=1:length(fNames)
            tmpFile = fullfile(pathCell{p}, fNames{i});
            [cmd]=sprintf('%s %s %s %s -o %s', gppPath,flags, includes, tmpFile, [fullfile(StellarisDir, fNames{i}) '.o']);
            [status, cmdout] = dos(cmd);
            % Check for Errors during compilation
            if status==1
                disp(cmdout);
            end
        end
    end
end

function par = getEthernetParameter
    par={};
    tgtData= get_param( bdroot, 'TargetExtensionData') ;
    % Get IP out of Model Parameter
    raw = tgtData.ip_address;
    parts = strsplit(raw, '.');
    if length(parts)==4
        % Correct IP size
        for i=1:length(parts)
           par{end+1} = parts{i}; 
        end
    else
        % Incorrect IP Size use standard....
        disp(' ### WARNING: Incorrect IP-Address given in Model Configuration!');
        disp('     Using default IP = 192.168.0.50');
        for i=1:4
           par{end+1} = FF; 
        end
    end
    % Get MAC out of Model Parameter
    raw = tgtData.mac_address;
    parts = strsplit(raw, ':');
    if length(parts)==6   
        % Correct MAC size
        for i=1:length(parts)
           par{end+1} = parts{i}; 
        end
    else
        %Wrong MAC-Adress use standard...
        disp(' ### WARNING: Incorrect MAC-Address given in Model Configuration!');
        disp('     Using default MAC = FF:FF:FF:FF:FF:FF');
        for i=1:6
           par{end+1} = FF; 
        end
    end
end