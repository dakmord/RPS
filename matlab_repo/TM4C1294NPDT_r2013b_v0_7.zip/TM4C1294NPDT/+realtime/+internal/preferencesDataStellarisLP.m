function info = preferencesDataStellarisLP(~)
% Get ModelConfiguration Data
tgtData= get_param( bdroot, 'TargetExtensionData') ;

if isequal( tgtData.( 'Set_host_COM_port') , 0)
    % Automatically detect COM port. 
    if isequal(realtime.internal.runStellarisLPCmd('setup_com'),1)
       % Found correct COMPort
       info = realtime.internal.getStellarisLPInfo('COMPORT');
    else
        % ERROR cannot find COMPort, use standard manual COMPort...
        info.COMPort= [ 'COM', tgtData.COM_port_number];
        info.COMPortNumber = num2str(tgtData.COM_port_number); %'11';
        info.UploadRate = '115200';
    end
else
    %If MANUAL COM-PORT selected..
    info.COMPort= [ 'COM', tgtData.COM_port_number];
    info.COMPortNumber = num2str(tgtData.COM_port_number);
    info.UploadRate = '115200';
    setpref('stellaris_lp','COMPort',info.COMPort);
end

info.InstallDir= ''; % dir of compiler ??? in arduino it is P:\Libs\Matlab\Targets\arduino-1.0

end
