function blkStruct = slblocks
  Browser.Library = 'stellaris_lp_lib';
  Browser.Name    = 'Run on Stellaris LaunchPad';
  blkStruct.Browser = Browser;