#include "Energia.h"
#include "inc/hw_types.h"
#include "inc/hw_nvic.h"
#include <stdio.h>
#include <stdarg.h>
//custom
#include <stdint.h>
#include <stdbool.h>



void ResetISR(void);
static void NmiSR(void);
static void FaultISR(void);
static void IntDefaultHandler(void);

extern void _c_int00(void);

extern unsigned long __STACK_TOP;

//*****************************************************************************
//
// External declaration for the interrupt handler used by the application.
//
//*****************************************************************************
//extern void UARTStdioIntHandler(void);
extern void UART0IntHandler(void);
extern void UART1IntHandler(void);
//extern void SvcCallHandler(void);
extern void SysTickIntHandler(void);

extern int main(void);
extern void GPIOAIntHandler(void);
extern void GPIOBIntHandler(void);
extern void GPIOCIntHandler(void);
extern void GPIODIntHandler(void);
extern void GPIOEIntHandler(void);
extern void GPIOFIntHandler(void);
extern void GPIOGIntHandler(void);
extern void GPIOHIntHandler(void);
extern void GPIOJIntHandler(void);
extern void GPIOKIntHandler(void);
extern void GPIOLIntHandler(void);
extern void GPIOMIntHandler(void);
extern void GPIONIntHandler(void);
extern void GPIOPIntHandler(void);
extern void GPIOQIntHandler(void);
#ifdef TARGET_IS_SNOWFLAKE_RA0
extern void GPIORIntHandler(void);
extern void GPIOSIntHandler(void);
extern void GPIOTIntHandler(void);
#endif
extern void lwIPEthernetIntHandler(void) __attribute__((weak));
extern void SysTickIntHandler(void);
/*
 * create some overridable default signal handlers
 */
__attribute__((weak)) void UARTIntHandler(void) {}
__attribute__((weak)) void UARTIntHandler1(void) {}
__attribute__((weak)) void UARTIntHandler2(void) {}
__attribute__((weak)) void UARTIntHandler3(void) {}
__attribute__((weak)) void UARTIntHandler4(void) {}
__attribute__((weak)) void UARTIntHandler5(void) {}
__attribute__((weak)) void UARTIntHandler6(void) {}
__attribute__((weak)) void UARTIntHandler7(void) {}
__attribute__((weak)) void ToneIntHandler(void) {}
__attribute__((weak)) void I2CIntHandler(void) {}

#pragma DATA_SECTION(g_pfnVectors, ".intvecs")
void (* const g_pfnVectors[])(void) =
{
    (void (*)(void))((unsigned long)&__STACK_TOP), // The initial stack pointer
    ResetISR,                               // The reset handler
    NmiSR,                                  // The NMI handler
    FaultISR,                               // The hard fault handler
    IntDefaultHandler,                      // The MPU fault handler
    IntDefaultHandler,                      // The bus fault handler
    IntDefaultHandler,                      // The usage fault handler
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    IntDefaultHandler,                         // SVCall handler
    IntDefaultHandler,                      // Debug monitor handler
    0,                                      // Reserved
    IntDefaultHandler,                      // The PendSV handler
    SysTickIntHandler,                      // The SysTick handler
    GPIOAIntHandler,                      // GPIO Port A
    GPIOBIntHandler,                      // GPIO Port B
    GPIOCIntHandler,                      // GPIO Port C
    GPIODIntHandler,                      // GPIO Port D
    GPIOEIntHandler,                      // GPIO Port E
    UARTIntHandler,                        // UART0 Rx and Tx
    UARTIntHandler1,                        // UART1 Rx and Tx
    IntDefaultHandler,                      // SSI0 Rx and Tx
    I2CIntHandler,                      // I2C0 Master and Slave
    IntDefaultHandler,                      // PWM Fault
    IntDefaultHandler,                      // PWM Generator 0
    IntDefaultHandler,                      // PWM Generator 1
    IntDefaultHandler,                      // PWM Generator 2
    IntDefaultHandler,                      // Quadrature Encoder 0
    IntDefaultHandler,                      // ADC Sequence 0
    IntDefaultHandler,                      // ADC Sequence 1
    IntDefaultHandler,                      // ADC Sequence 2
    IntDefaultHandler,                      // ADC Sequence 3
    IntDefaultHandler,                      // Watchdog timer
    IntDefaultHandler,                       // Timer 0 subtimer A
    IntDefaultHandler,                      // Timer 0 subtimer B
    IntDefaultHandler,                      // Timer 1 subtimer A
    IntDefaultHandler,                      // Timer 1 subtimer B
    IntDefaultHandler,                      // Timer 2 subtimer A
    IntDefaultHandler,                      // Timer 2 subtimer B
    IntDefaultHandler,                      // Analog Comparator 0
    IntDefaultHandler,                      // Analog Comparator 1
    IntDefaultHandler,                      // Analog Comparator 2
    IntDefaultHandler,                      // System Control (PLL, OSC, BO)
    IntDefaultHandler,                      // FLASH Control
    GPIOFIntHandler,                      // GPIO Port F
    GPIOGIntHandler,                      // GPIO Port G
    GPIOHIntHandler,                      // GPIO Port H
    UARTIntHandler2,                      // UART2 Rx and Tx
    IntDefaultHandler,                      // SSI1 Rx and Tx
    IntDefaultHandler,                      // Timer 3 subtimer A
    IntDefaultHandler,                      // Timer 3 subtimer B
    I2CIntHandler,                      // I2C1 Master and Slave
    IntDefaultHandler,                      // Quadrature Encoder 1
    IntDefaultHandler,                      // CAN0
    IntDefaultHandler,                      // CAN1
    IntDefaultHandler,                      // CAN2
    IntDefaultHandler,                      // Ethernet
    IntDefaultHandler,                      // Hibernate
    IntDefaultHandler,                      // USB0
    IntDefaultHandler,                      // PWM Generator 3
    IntDefaultHandler,                      // uDMA Software Transfer
    IntDefaultHandler,                      // uDMA Error
    IntDefaultHandler,                      // ADC1 Sequence 0
    IntDefaultHandler,                      // ADC1 Sequence 1
    IntDefaultHandler,                      // ADC1 Sequence 2
    IntDefaultHandler,                      // ADC1 Sequence 3
    IntDefaultHandler,                      // I2S0
    IntDefaultHandler,                      // External Bus Interface 0
    GPIOJIntHandler,                      // GPIO Port J
    GPIOKIntHandler,                      // GPIO Port K
    GPIOLIntHandler,                      // GPIO Port L
    IntDefaultHandler,                      // SSI2 Rx and Tx
    IntDefaultHandler,                      // SSI3 Rx and Tx
    UARTIntHandler3,                      // UART3 Rx and Tx
    UARTIntHandler4,                      // UART4 Rx and Tx
    UARTIntHandler5,                      // UART5 Rx and Tx
    UARTIntHandler6,                      // UART6 Rx and Tx
    UARTIntHandler7,                      // UART7 Rx and Tx
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    I2CIntHandler,                      // I2C2 Master and Slave
    I2CIntHandler,                      // I2C3 Master and Slave
    ToneIntHandler,                      // Timer 4 subtimer A
    IntDefaultHandler,                      // Timer 4 subtimer B
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    0,                                      // Reserved
    IntDefaultHandler,                      // Timer 5 subtimer A
    IntDefaultHandler,                      // Timer 5 subtimer B
    IntDefaultHandler,                      // Wide Timer 0 subtimer A
    IntDefaultHandler,                      // Wide Timer 0 subtimer B
    IntDefaultHandler,                      // Wide Timer 1 subtimer A
    IntDefaultHandler,                      // Wide Timer 1 subtimer B
    IntDefaultHandler,                      // Wide Timer 2 subtimer A
    IntDefaultHandler,                      // Wide Timer 2 subtimer B
    IntDefaultHandler,                      // Wide Timer 3 subtimer A
    IntDefaultHandler,                      // Wide Timer 3 subtimer B
    IntDefaultHandler,                      // Wide Timer 4 subtimer A
    IntDefaultHandler,                      // Wide Timer 4 subtimer B
    IntDefaultHandler,                      // Wide Timer 5 subtimer A
    IntDefaultHandler,                      // Wide Timer 5 subtimer B
    IntDefaultHandler,                      // FPU
    IntDefaultHandler,                      // PECI 0
    IntDefaultHandler,                      // LPC 0
    IntDefaultHandler,                      // I2C4 Master and Slave
    IntDefaultHandler,                      // I2C5 Master and Slave
    GPIOMIntHandler,                      // GPIO Port M
    GPIONIntHandler,                      // GPIO Port N
    IntDefaultHandler,                      // Quadrature Encoder 2
    IntDefaultHandler,                      // Fan 0
    0,                                      // Reserved
    GPIOPIntHandler,                      // GPIO Port P (Summary or P0)
    GPIOPIntHandler,                      // GPIO Port P1
    GPIOPIntHandler,                      // GPIO Port P2
    GPIOPIntHandler,                      // GPIO Port P3
    GPIOPIntHandler,                      // GPIO Port P4
    GPIOPIntHandler,                      // GPIO Port P5
    GPIOPIntHandler,                      // GPIO Port P6
    GPIOPIntHandler,                      // GPIO Port P7
    GPIOQIntHandler,                      // GPIO Port Q (Summary or Q0)
    GPIOQIntHandler,                      // GPIO Port Q1
    GPIOQIntHandler,                      // GPIO Port Q2
    GPIOQIntHandler,                      // GPIO Port Q3
    GPIOQIntHandler,                      // GPIO Port Q4
    GPIOQIntHandler,                      // GPIO Port Q5
    GPIOQIntHandler,                      // GPIO Port Q6
    GPIOQIntHandler,                      // GPIO Port Q7
    IntDefaultHandler,                      // GPIO Port R
    IntDefaultHandler,                      // GPIO Port S
    IntDefaultHandler,                      // PWM 1 Generator 0
    IntDefaultHandler,                      // PWM 1 Generator 1
    IntDefaultHandler,                      // PWM 1 Generator 2
    IntDefaultHandler,                      // PWM 1 Generator 3
    IntDefaultHandler                       // PWM 1 Fault
};

void ResetISR(void)
{
    __asm("    .global _c_int00\n"
            "    b.w     _c_int00");
}

#define LED_RED 0x2
#define LED_BLUE 0x4
#define LED_GREEN 0x8

#define GPIO_PORTF_DATA_R       (*((volatile unsigned long *)0x400253FC))
static void NmiSR(void)
{
    while(1)
    {
        GPIO_PORTF_DATA_R = LED_GREEN;
    }
}

static void FaultISR(void)
{
    while(1)
    {
        GPIO_PORTF_DATA_R = LED_BLUE;
    }
}

static void IntDefaultHandler(void)
{
    while(1)
    {
        GPIO_PORTF_DATA_R = LED_RED;
    }
}
