#include "customFunctions.h"

//Custom isBlank
bool isblank(int c)
{
  if(c==9 || c==32)
      return true;
  else 
      return false;
}

