#ifndef __STELLARIS_RUNTIME_H__
#define __STELLARIS_RUNTIME_H__

void system_init(void);
void system_reset(void);
void system_safe(void);
void system_delay_ms(int ms);

// debug declaration
void            led_debug_signal(int id);


#define LED_RED     0x2
#define LED_BLUE    0x4
#define LED_GREEN   0x8
#define LED_ALL     (LED_RED|LED_BLUE|LED_GREEN)

#define     LED_DEBUG_RESET     0
#define     LED_DEBUG_OVERRUN   1
#define     LED_DEBUG_ALL_ON    2
#define     LED_DEBUG_ALL_OFF   3
#define     LED_DEBUG_REENTRANCE 4


// real time tick setup
#define     TICK_DEBUG  0
void            tick_init(float step_size);
void            systick_init(float step_size);
void            systick_intr_enable(void);
void            systick_intr_disable(void);
void            check_overrun();


#endif // __STELLARIS_RUNTIME_H__
