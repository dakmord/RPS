#include <limits.h>

//custom include cause Tiva CNT
#include <stdint.h>
#include <stdbool.h>
//#include "Energia.h"


#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "inc/tm4c1294ncpdt.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
//#define PART_LM4F120H5QR
#include "driverlib/debug.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"
#include "driverlib/interrupt.h"


//#include "I2C_Stellaris_API.h"
//#include "ssi_API.h"

#include "stellaris_runtime.h"
#include "reentrance.h"

//#include "uart_driver_mp.h"
//#include "xprintf.h"

static void tick_handler(void);
uint32_t ui32SysClock;

//void rt_OneStepM(void);
void rt_OneStep(void);

void system_init(void)
{   


    // safty first
    system_safe();
    
	//init system
    //
    // Enable lazy stacking for interrupt handlers.  This allows floating-point
    // instructions to be used within interrupt handlers, but at the expense of
    // extra stack usage.
    //
    if (LAZY_STACKING)
    {
        MAP_FPULazyStackingEnable();
    } else {
        MAP_FPUStackingEnable();
    }

								 
	// set sys clock 100MHZ
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN |
                  SYSCTL_XTAL_16MHZ);
    //ui32SysClock = MAP_SysCtlClockGet();
	// enable all pins
	/*
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
	*/
	
    //reset visual clue
    //led_debug_signal(LED_DEBUG_RESET);

    // Enable processor interrupts.
    //
	

    MAP_IntMasterEnable();
	
	// INIT TEST LED
	SYSCTL_RCGCGPIO_R = SYSCTL_RCGCGPIO_R12;
    SYSCTL_RCGCGPIO_R;
    GPIO_PORTN_DIR_R = 0x01;
    GPIO_PORTN_DEN_R = 0x01;
	// LED ON
	GPIO_PORTN_DATA_R |= 0x01;
}
void system_reset(void)
{
    system_safe();
    MAP_SysCtlReset();
}
void system_safe(void)
{
    //pwm_shutdown();
}

void system_delay_ms(int ms)
{
	MAP_SysCtlDelay(MAP_SysCtlClockGet()/1000 * ms / 3 );
}

void led_debug_signal(int id)
{
    MAP_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, LED_ALL);
    switch(id)
    {        
    case LED_DEBUG_RESET: //reset

        led_debug_signal(LED_DEBUG_ALL_ON);
        system_delay_ms(200);
        led_debug_signal(LED_DEBUG_ALL_OFF);
        system_delay_ms(100);
        led_debug_signal(LED_DEBUG_ALL_ON);
        system_delay_ms(200);
        led_debug_signal(LED_DEBUG_ALL_OFF);
        system_delay_ms(100);
        break;
        
     case LED_DEBUG_OVERRUN: // overrun
        while(1)
        {
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, LED_BLUE);
            system_delay_ms(100);
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, LED_GREEN);
            system_delay_ms(100);
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, LED_RED);
            system_delay_ms(100);
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, 0);
            system_delay_ms(100);
        }
        //break;
     case LED_DEBUG_REENTRANCE: // re-entrance stack corruption
        while(1)
        {
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, LED_BLUE);
            system_delay_ms(500);
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, 0);
            system_delay_ms(300);
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, LED_RED);
            system_delay_ms(500);
            MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, 0);
            system_delay_ms(300);
        }
        //break;
     case LED_DEBUG_ALL_ON:
        MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, LED_ALL);
        break;     
     case LED_DEBUG_ALL_OFF:
        MAP_GPIOPinWrite(GPIO_PORTN_BASE,  LED_ALL, 0);
        break;
    }
}

///////////////////////////////////////////////////////////////////////////
//   
//  Systick functions
//
///////////////////////////////////////////////////////////////////////////

void systick_init(float step_size)
{
	MAP_IntPrioritySet(FAULT_SYSTICK, 0xC0); //MAP
	
	//ROM_SysTickPeriodSet( ROM_SysCtlClockGet() * step_size );
	MAP_SysTickPeriodSet( 1000000 );
 //PROBLEM!!!!
	
	systick_intr_enable();

    MAP_SysTickEnable();
	

}

void systick_intr_enable()
{
	MAP_SysTickIntEnable();
}

void systick_intr_disable()
{
	MAP_SysTickIntDisable();
}


void tick_init(float step_size)
{
	
    // Enable the timer which runs our application
    //
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    //
    // Configure the 32-bit periodic timer.
    //
    MAP_TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    MAP_TimerLoadSet(TIMER0_BASE, TIMER_A, MAP_SysCtlClockGet() * step_size);
    
    //
    // Setup the interrupt for the timer timeout.
    //
    MAP_IntEnable(INT_TIMER0A);
    MAP_TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    
    //
    // Enable the timer.
    //
    MAP_TimerEnable(TIMER0_BASE, TIMER_A);

}

void check_overrun()
{
    //
    // If the Timer0A already timeout after the process, there is a overrun
    // condition.
    //
    if (MAP_TimerIntStatus(TIMER0_BASE,false) & TIMER_TIMA_TIMEOUT)
    {
        // over run!! disable timer and stuck here.
        MAP_IntMasterDisable();
        MAP_TimerDisable(TIMER0_BASE, TIMER_A);
        while(1)
        {
          led_debug_signal(1);
        }
		
    }
}

void SysTickIntHandler(void)
{
	
    ExitIsrAndRun(tick_handler);
    //tick_handler();
}

void SvcCallHandler(void)
{
    ExitIsrAndRun_SVC();
}


#if TICK_DEBUG
volatile long long tick_count = ~0;
volatile long long tick_pause = ~0;
#endif

void tick_handler(void)
{

#if TICK_DEBUG
    if (++tick_count == tick_pause)
    {
        systick_intr_disable();
        while(tick_count == tick_pause);
        systick_intr_enable();
    }
#endif
	
	// BLINK TEST LED
	if((GPIO_PORTN_DATA_R&0x01)==0x00){
    GPIO_PORTN_DATA_R |= 0x01;
	}
	else {
	GPIO_PORTN_DATA_R &= ~(0x01);
	}

    //
    // Run the application step function
    //
    systick_intr_disable();
    rt_OneStep();
    //rt_OneStepM();    
    systick_intr_enable();
    // if overrun, alert user and stop
    // check_overrun();
}

void tick_error_halt(void)
{
    MAP_IntMasterDisable();
    led_debug_signal(LED_DEBUG_REENTRANCE);
}
